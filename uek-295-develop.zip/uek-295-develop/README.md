# Description

ICT-UEK 295 Prüfungsvorlage.

## Test

Es gibt mehrere Tests

für dich Massgebend sind die Tests, welche mit test-todo.... beginnen. Nur diese Tests werden in der Pipeline laufen gelassen.

```bash
# unit tests
$ npm run test-todo

# e2e tests
$ npm run test-todo:e2e

# test coverage
$ npm run test-todo:cov
```
## Planung so wie Fazit sind nach Absprache mit Ramon im Excel zu finden

## Planung

Hier kommt deine Projektplanung hin

### Projektinformationen
Projektname: 
Projektdauer: 
Ersteller: 

### Vorgehen / Aufgaben-tabelle

| Aufgabe | soll Zeit | aufwand / h  | ist aufwand /h |
|-------|------------|--------------|----------------|
| ....  |            |              |                |
|       |            |              |                |
|       |            |              |                |
|       |            |              |                |
|       |            |              |                |
|       |            |              |                |
|       |            |              |                |
etc.

## Fazit
.... hier kommt dein Fazit zur Aufgabe rein
