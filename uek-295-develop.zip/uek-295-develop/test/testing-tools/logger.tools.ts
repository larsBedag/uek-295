import { LoggerService } from '@nestjs/common';

export class TestLogger implements LoggerService {
  log() {
    //
  }
  error() {
    //
  }
  warn() {
    //
  }
  debug() {
    //
  }
  verbose() {
    //
  }
}
