export class Constants {
  static readonly correlationId = 'correlationId';
  static readonly user = 'user';
}
