import { Test, TestingModule } from '@nestjs/testing';
import { TodoController } from './todo.controller';
import { TodoService } from './todo.service';
import { UserEntity } from '../../sample/generic.dtos/userDtoAndEntity';
import { Todo } from './entities/todo.entity';

const userUser: UserEntity = {
  userId: 1,
  username: 'user',
  password: '12345',
  roles: ['user'],
};
const adminUser: UserEntity = {
  userId: 2,
  username: 'admin',
  password: '12345',
  roles: ['user', 'admin'],
};

const todo1: Todo = {
  id: 1,
  title: 'Mein Todo',
  description: 'Beschreibung',
  closed: false,
};
class TodoServiceMockup {
  findAll() {
    return [];
  }
  findOne() {
    return todo1;
  }
  create() {
    return todo1;
  }
  replace() {
    return todo1;
  }
  update() {
    return todo1;
  }
  remove() {
    return todo1;
  }
}

describe('TodoController', () => {
  let controller: TodoController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [TodoController],
      providers: [{ provide: TodoService, useClass: TodoServiceMockup }],
    }).compile();

    controller = module.get<TodoController>(TodoController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('findAll', async () => {
    expect(await controller.findAll(0)).toEqual([]);
  });

  it('findOne', async () => {
    expect(await controller.findOne(0, 1)).toEqual(todo1);
  });

  it('create', async () => {
    expect(await controller.create(0, todo1)).toEqual(todo1);
  });

  it('replace', async () => {
    expect(await controller.replace(0, 1, todo1)).toEqual(todo1);
  });

  it('update', async () => {
    expect(await controller.update(0, 1, { title: 'Mein Todo' })).toEqual(todo1);
  });

  it('remove working as admin', async () => {
    expect(await controller.remove(adminUser, 0, 1)).toEqual(todo1);
  });

  it('remove not working as user', async () => {
    try {
      await controller.remove(userUser, 0, 1);
    } catch (err: any) {
      expect(err.message).toBe('You have to be member of the role admin to call this method!');
    }
  });
});
