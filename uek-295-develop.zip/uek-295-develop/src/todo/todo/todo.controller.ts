import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
  ParseIntPipe,
  ForbiddenException,
  Put,
} from '@nestjs/common';
import { TodoService } from './todo.service';
import { CreateTodoDto } from './dto/create-todo.dto';
import { UpdateTodoDto } from './dto/update-todo.dto';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiCreatedResponse,
  ApiForbiddenResponse,
  ApiMethodNotAllowedResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiTags,
  ApiUnauthorizedResponse,
} from '@nestjs/swagger';
import { BaseController } from '../../sample/base/base.controller';
import { JwtAuthGuard } from '../../sample/modules/auth/guards/jwt-auth.guard';
import { ArticleReturnDto } from '../../sample/modules/article/dto/article-return-dto';
import { ErrorDto } from '../../sample/generic.dtos/error.dto';
import { ErrorUnauthorizedDto } from '../../sample/generic.dtos/error.unauthorized.dto';
import { ReturnTodoDto } from './dto/return-todo.dto';
import { CorrId } from '../../sample/decorators/correlation-id/correlation-id.decorator';
import { CurrentUser } from '../../sample/decorators/current-user/current-user.decorator';
import { UserEntity } from '../../sample/generic.dtos/userDtoAndEntity';

@Controller('todo')
@ApiTags('Todo Methods')
@ApiBearerAuth()
export class TodoController extends BaseController {
  constructor(private readonly todoService: TodoService) {
    super('TodoController');
  }
  @UseGuards(JwtAuthGuard)
  @Post()
  @ApiCreatedResponse({ description: 'The record has been successfully created.', type: ReturnTodoDto })
  @ApiMethodNotAllowedResponse({ description: `You don't have the right to access this record.`, type: ErrorDto })
  @ApiUnauthorizedResponse({ description: 'Not logged in!', type: ErrorUnauthorizedDto })
  async create(@CorrId() corrId: number, @Body() createTodoDto: CreateTodoDto): Promise<ReturnTodoDto> {
    const methodName = 'create';
    this.wl(corrId, methodName);
    const obj = await this.todoService.create(corrId, createTodoDto);
    return ReturnTodoDto.ConvertEntityToDto(obj);
  }

  @UseGuards(JwtAuthGuard)
  @Get()
  @ApiOkResponse({ description: 'The record has been found.', type: ReturnTodoDto, isArray: true })
  @ApiUnauthorizedResponse({ description: 'Not logged in!', type: ErrorUnauthorizedDto })
  async findAll(@CorrId() corrId: number): Promise<ReturnTodoDto[]> {
    const methodName = 'findAll';
    this.wl(corrId, methodName);
    const arr = await this.todoService.findAll(corrId);
    return arr.map((item) => ReturnTodoDto.ConvertEntityToDto(item));
  }

  @UseGuards(JwtAuthGuard)
  @Get(':id')
  @ApiOkResponse({ description: 'The record has been found.', type: ReturnTodoDto })
  @ApiNotFoundResponse({ description: 'The record has not been found.', type: ErrorDto })
  @ApiUnauthorizedResponse({ description: 'Not logged in!', type: ErrorUnauthorizedDto })
  async findOne(@CorrId() corrId: number, @Param('id', ParseIntPipe) id: number): Promise<ReturnTodoDto> {
    const methodName = 'findOne';
    this.wl(corrId, methodName);
    const item = await this.todoService.findOne(corrId, id);
    return ReturnTodoDto.ConvertEntityToDto(item);
  }

  @UseGuards(JwtAuthGuard)
  @Put(':id')
  @ApiOkResponse({ description: 'The record has been successfully replaced.', type: ReturnTodoDto })
  @ApiBadRequestResponse({ description: `You not allowed to replace the record.`, type: ErrorDto })
  @ApiMethodNotAllowedResponse({ description: `You don't have the right to access this record.`, type: ErrorDto })
  @ApiUnauthorizedResponse({ description: 'Not logged in!', type: ErrorUnauthorizedDto })
  async replace(
    @CorrId() corrId: number,
    @Param('id', ParseIntPipe) id: number,
    @Body() todo: ReturnTodoDto,
  ): Promise<ReturnTodoDto> {
    const methodName = 'replace';
    this.wl(corrId, methodName);
    const item = await this.todoService.replace(corrId, id, todo);
    return ReturnTodoDto.ConvertEntityToDto(item);
  }

  @UseGuards(JwtAuthGuard)
  @Patch(':id')
  @ApiOkResponse({ description: 'The record has been successfully updated.', type: ReturnTodoDto })
  @ApiNotFoundResponse({ description: 'The record has not been found.', type: ErrorDto })
  @ApiUnauthorizedResponse({ description: 'Not logged in!', type: ErrorUnauthorizedDto })
  async update(
    @CorrId() corrId: number,
    @Param('id', ParseIntPipe) id: number,
    @Body() updateTodoDto: UpdateTodoDto,
  ): Promise<ReturnTodoDto> {
    const methodName = 'update';
    this.wl(corrId, methodName);
    const obj = await this.todoService.update(corrId, id, updateTodoDto);
    return ReturnTodoDto.ConvertEntityToDto(obj);
  }

  @UseGuards(JwtAuthGuard)
  @Delete(':id')
  @ApiOkResponse({ description: 'The record has been successfully deleted.', type: ArticleReturnDto })
  @ApiNotFoundResponse({ description: 'The record has not been found.', type: ErrorDto })
  @ApiForbiddenResponse({ description: '', type: ErrorDto })
  @ApiUnauthorizedResponse({ description: 'Not logged in!', type: ErrorUnauthorizedDto })
  async remove(
    @CurrentUser() user: UserEntity,
    @CorrId() corrId: number,
    @Param('id', ParseIntPipe) id: number,
  ): Promise<ReturnTodoDto> {
    const methodName = 'remove';
    if (user.roles.find((role) => role === 'admin')) {
      this.wl(corrId, methodName);
      const obj = await this.todoService.remove(corrId, id);
      return ReturnTodoDto.ConvertEntityToDto(obj);
    } else {
      throw new ForbiddenException('You have to be member of the role admin to call this method!');
    }
  }
}
