import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';
import { IsNotEmpty } from 'class-validator';

@Entity({
  name: 'todo',
})
export class Todo {
  @PrimaryGeneratedColumn({
    primaryKeyConstraintName: 'pk-todo',
  })
  id: number;

  @Column()
  @IsNotEmpty()
  title: string;

  @Column()
  @IsNotEmpty()
  description: string;

  @Column()
  @IsNotEmpty()
  closed: boolean = false;
}
