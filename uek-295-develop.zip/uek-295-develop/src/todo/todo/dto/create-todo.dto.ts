import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class CreateTodoDto {
  @IsNotEmpty()
  @ApiProperty({
    description: 'The description of the todo',
    default: 'meine Beschreibung',
    example: 'Beispiel Beschreibung',
  })
  description: string;

  @IsNotEmpty()
  @ApiProperty()
  title: string;
}
