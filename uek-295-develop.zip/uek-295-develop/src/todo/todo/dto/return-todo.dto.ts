import { ApiProperty } from '@nestjs/swagger';

export class ReturnTodoDto {
  @ApiProperty({
    description: 'The unique id of the todo',
    minimum: 1,
    default: 1,
    example: 1,
  })
  id: number;

  @ApiProperty({
    description: 'The title of the todo',
    default: 'mein Todo',
    example: 'Beispiel Todo',
  })
  title: string;

  @ApiProperty({
    description: 'The description of the todo',
    default: 'meine Beschreibung',
    example: 'Beispiel Beschreibung',
  })
  description: string;

  @ApiProperty({
    description: 'The status of the todo',
    default: false,
    example: false,
  })
  closed: boolean;

  static ConvertEntityToDto(entity: any): ReturnTodoDto {
    return entity as ReturnTodoDto;
  }
}
