import { PartialType } from '@nestjs/mapped-types';
import { CreateTodoDto } from './create-todo.dto';
import { ApiProperty } from '@nestjs/swagger';

export class UpdateTodoDto extends PartialType(CreateTodoDto) {
  @ApiProperty({
    description: 'The unique id of the todo',
    minimum: 1,
    default: 1,
    example: 1,
  })
  description?: string;

  @ApiProperty({
    description: 'The title of the todo',
    default: 'mein Todo',
    example: 'Beispiel Todo',
  })
  title?: string;

  @ApiProperty({
    description: 'The status of the todo',
    default: false,
    example: false,
  })
  closed?: boolean;
}
