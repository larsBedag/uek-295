import { BadRequestException, Injectable, Logger, MethodNotAllowedException, NotFoundException } from '@nestjs/common';
import { CreateTodoDto } from './dto/create-todo.dto';
import { UpdateTodoDto } from './dto/update-todo.dto';
import { BaseService } from '../../sample/base/base.service';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Todo } from './entities/todo.entity';

@Injectable()
export class TodoService extends BaseService {
  constructor(@InjectRepository(Todo) private todoRepository: Repository<Todo>) {
    super('todo.service');
  }
  async create(corrId: number, createTodoDto: CreateTodoDto): Promise<Todo> {
    const method = 'create';
    this.wl(corrId, method);
    // extend the createDto with the timestamp
    const todo: Todo = { ...createTodoDto, id: null, closed: false };
    Logger.log(todo);
    // check if all required fields are set, if not the method is throw an error
    this.checkForAllRequiredProperties(corrId, todo);
    // create the object and convert the return value to the right datatype
    const identifier = (await this.todoRepository.insert(todo)).identifiers;
    const obj = await this.todoRepository.findOneBy(identifier[0]);
    this.wl(corrId, method, `create a new todo item with id: ${todo.id}. ret: ${JSON.stringify(obj, null, 2)}`);
    return obj;
  }

  async findAll(corrId: number): Promise<Todo[]> {
    const method = 'findAll';
    this.wl(corrId, method);
    // just return the full array content
    const ret = await this.todoRepository.find();
    this.wl(corrId, method, `we return all items in the array. Current length is ${ret.length}`);
    this.wl(corrId, method, `ret: ${JSON.stringify(ret, null, 2)}`);
    return ret;
  }

  async findOne(corrId: number, id: number): Promise<Todo> {
    const methodName = 'findOne';
    this.wl(corrId, methodName);
    const todo: Todo = await this.todoRepository.findOneBy({ id });
    // check if the id was found. find returns undefined in case nothing was found
    if (!todo) {
      const msg = `We did not found a todo item with id ${id}!`;
      this.wl(corrId, methodName, msg);
      throw new NotFoundException(msg);
    }
    this.wl(corrId, methodName, `we find todo item with id: ${id}. ret: ${JSON.stringify(todo, null, 2)}`);
    return todo;
  }

  async replace(corrId: number, id: number, entity: Todo): Promise<Todo> {
    const methodName = 'replace';
    this.wl(corrId, methodName);
    // check if all required fields are set, if not the method is throw an error
    this.checkForAllRequiredProperties(corrId, entity);

    // check that the resource id is equal to the object id
    if (id !== entity.id) {
      const msg = `The id of the resource is not equal to the id of the object!`;
      this.wl(corrId, methodName, msg);
      throw new BadRequestException(msg);
    }

    const oldObj = await this.todoRepository.findOneBy({ id });
    if (!oldObj) {
      const msg = `No todo found with id ${id}`;
      this.wl(corrId, methodName, msg);
      throw new MethodNotAllowedException(msg);
    }

    this.wl(
      corrId,
      methodName,
      `we find todo item with id: ${id} and replaced it with the new values ${JSON.stringify(entity, null, 2)}!`,
    );
    await this.todoRepository.update({ id }, this.sanitizeTodoObject(corrId, entity));
    const updatedObj = await this.todoRepository.findOneBy({ id });
    this.wl(
      corrId,
      methodName,
      `we find todo item with id: ${id} and replaced it with the new values ${JSON.stringify(updatedObj, null, 2)}!`,
    );
    return updatedObj;
  }

  async update(corrId: number, id: number, updateTodoDto: UpdateTodoDto): Promise<Todo> {
    const oldObj = await this.todoRepository.findOneBy({ id });
    if (!oldObj) {
      const msg = `No todo found with id ${id}`;
      this.wl(corrId, 'update', msg);
      throw new NotFoundException(msg);
    }
    for (const key of Object.keys(updateTodoDto)) {
      if (oldObj[key]) {
        oldObj[key] = updateTodoDto[key];
      }
    }
    await this.todoRepository.update({ id }, oldObj);
    const updatedObj = await this.todoRepository.findOneBy({ id });
    this.wl(
      corrId,
      'update',
      `we find article item with id: ${id} and added the new values ${JSON.stringify(updatedObj, null, 2)}!`,
    );

    return updatedObj;
  }

  async remove(corrId: number, id: number): Promise<Todo> {
    const methodName = 'remove';
    this.wl(corrId, methodName);
    const oldObj = await this.todoRepository.findOneBy({ id });
    // check if the id was found. find returns undefined in case nothing was found
    if (!oldObj) {
      const msg = `We did not found a todo item with id ${id}!`;
      this.wl(corrId, methodName, msg);
      throw new NotFoundException(msg);
    }
    await this.todoRepository.delete({ id });
    this.wl(
      corrId,
      methodName,
      `we find todo item with id: ${id} so we deleted it! ret: ${JSON.stringify(oldObj, null, 2)}`,
    );
    return oldObj;
  }

  private checkForAllRequiredProperties(corrId: number, todo: Todo) {
    const methodName = 'checkForAllRequiredProperties';
    this.wl(corrId, methodName);
    if (!todo.description) {
      const msg = `The required field description is missing in the object!`;
      this.wl(corrId, methodName, msg);
      throw new BadRequestException(msg);
    }
    if (!todo.title) {
      const msg = `The required field title is missing in the object!`;
      this.wl(corrId, methodName, msg);
      throw new BadRequestException(msg);
    }
    if (todo.closed == null) {
      const msg = `The required field closed is missing in the object!`;
      this.wl(corrId, methodName, msg);
      throw new BadRequestException(msg);
    }
  }
  private sanitizeTodoObject(corrId: number, todo: Todo): Todo {
    const methodName = 'sanitizeTodoObject';
    this.wl(corrId, methodName);
    return {
      id: todo.id,
      title: todo.title,
      description: todo.description,
      closed: todo.closed,
    };
  }
}
