# Aufgabe

In diesem Verzeichnis sollte dein Code liegen.


```bash
nest g resource todo
```
Wir erstellen ein:

- REST API
mit
- CRUD endpoints

Du brauchst diese Datei später nicht mehr und kannst sie ruhig löschen!
